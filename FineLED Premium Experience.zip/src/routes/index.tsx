import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  Award,
  Building2,
  CheckCircle2,
  Clock,
  Cpu,
  Globe2,
  Headphones,
  Landmark,
  Layers,
  Mail,
  MapPin,
  Menu,
  Minus,
  Phone,
  Plane,
  Plus,
  Quote,
  Shield,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Star,
  Trophy,
  Volume2,
  X,
  Zap,
} from "lucide-react";
import heroLed from "@/assets/hero-led.jpg";
import heroVideoAsset from "@/assets/hero-led.mp4.asset.json";
import aboutLed from "@/assets/about-led.jpg";
import projBillboard from "@/assets/project-billboard.jpg";
import projMall from "@/assets/project-mall.jpg";
import projAirport from "@/assets/project-airport.jpg";
import projHotel from "@/assets/project-hotel.jpg";
import teamGroup from "@/assets/team-group.jpg.asset.json";

import solIndoor from "@/assets/sol-indoor.jpg";
import solOutdoor from "@/assets/sol-outdoor.jpg";
import solCreative from "@/assets/sol-creative.jpg";
import solTransparent from "@/assets/sol-transparent.jpg";
import solRental from "@/assets/sol-rental.jpg";
import solControl from "@/assets/sol-control.jpg";
import fineledLogo from "@/assets/fineled-logo.png.asset.json";
import galfarLogo from "@/assets/partners/chembur-150x150_1.png.asset.json";
import bobyLogo from "@/assets/partners/chemur-150x150_1.png.asset.json";
import dubaiHoldingLogo from "@/assets/partners/dubai-hl-150x150_2.png.asset.json";
import globalVillageLogo from "@/assets/partners/global-150x150_1.png.asset.json";
import jjLogo from "@/assets/partners/jj-150x150_1.png.asset.json";
import royalKingLogo from "@/assets/partners/lion-150x150_1.png.asset.json";
import malabarLogo from "@/assets/partners/malab-150x150_1.png.asset.json";
import morickapLogo from "@/assets/partners/mori-150x150_1.png.asset.json";
import nishkaLogo from "@/assets/partners/nishi-150x150_1.png.asset.json";
import rakPoliceLogo from "@/assets/partners/Rak-police-150x150_1.png.asset.json";
import shababLogo from "@/assets/partners/shad-150x150_1.png.asset.json";
import stsLogo from "@/assets/partners/stc-150x150_1.png.asset.json";
import vexusLogo from "@/assets/partners/vex-150x150_1.png.asset.json";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FineLED: Premium LED Display Solutions Across the GCC" },
      {
        name: "description",
        content:
          "FineLED engineers and installs landmark LED displays for architecture, retail, hospitality and infrastructure across Oman, the UAE and worldwide. 25+ years, 3000+ projects, 1000+ events, 2000+ clients.",
      },
      { property: "og:title", content: "FineLED: Premium LED Display Solutions" },
      {
        property: "og:description",
        content:
          "Award-winning LED installations for the GCC's most ambitious spaces. Engineered to last, designed to be remembered.",
      },
      { property: "og:image", content: heroLed },
      { name: "twitter:image", content: heroLed },
    ],
  }),
  component: Home,
});

import { Btn, Eyebrow, Reveal, SiteLayout } from "@/components/site-chrome";


/* ---------------- Hero ---------------- */

function Hero() {
  const { t } = useLang();
  return (
    <section id="top" className="relative isolate min-h-screen flex flex-col bg-[#0c0606] overflow-hidden">
      {/* Full-bleed background video */}
      <video
        src={heroVideoAsset.url}
        poster={heroLed}
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        className="absolute inset-0 -z-10 h-full w-full object-cover scale-105 motion-safe:animate-[heroZoom_18s_ease-out_forwards]"
      />
      {/* Gradient overlays for legibility */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-black/75 via-black/55 to-black/90" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-black/80 via-black/30 to-transparent" />
      {/* Soft burgundy vignette */}
      <div
        className="absolute inset-0 -z-10 opacity-50 mix-blend-soft-light"
        style={{
          background:
            "radial-gradient(60% 50% at 20% 80%, rgba(109,41,50,0.55), transparent 70%)",
        }}
      />

      <div className="container-editorial flex-1 flex items-center pt-[140px] pb-24 lg:pt-[180px] lg:pb-32">
        <div className="max-w-[820px]">
          <div className="eyebrow !text-[color:var(--taupe)] opacity-0 animate-[heroFade_900ms_ease-out_200ms_forwards]">
            {t("LED Display Solutions · GCC")}
          </div>
          <h1 className="display-xl mt-6 text-white opacity-0 animate-[heroFade_1000ms_ease-out_400ms_forwards]">
            {t("Brightness, shaped")} <br className="hidden sm:block" />
            {t("with intention.")}
          </h1>
          <p className="mt-8 max-w-[540px] text-[16px] leading-[1.75] text-white/80 opacity-0 animate-[heroFade_900ms_ease-out_1100ms_forwards]">
            {t("From indoor video walls and outdoor billboards to transparent displays, stadium screens and immersive digital experiences, FineLED delivers complete end-to-end LED and AV solutions across Oman, the UAE and the wider GCC.")}
          </p>
          <div className="mt-10 flex flex-wrap gap-4 opacity-0 animate-[heroFade_900ms_ease-out_1300ms_forwards]">
            <a
              href="#contact"
              className="inline-flex items-center gap-2 h-12 px-7 rounded-full bg-white text-primary text-[14px] font-medium hover:bg-[color:var(--taupe)] transition-colors"
            >
              {t("Start a Project")} <ArrowUpRight className="h-4 w-4 rtl:-scale-x-100" />
            </a>
            <a
              href="#projects"
              className="inline-flex items-center gap-2 h-12 px-7 rounded-full border border-white/40 text-white text-[14px] font-medium hover:bg-white/10 transition-colors"
            >
              {t("View Our Work")}
            </a>
          </div>
        </div>
      </div>

      {/* Stats strip pinned to bottom of hero */}
      <div className="relative border-t border-white/15 bg-black/30 backdrop-blur-md opacity-0 animate-[heroFade_900ms_ease-out_1500ms_forwards]">
        <div className="container-editorial grid grid-cols-2 lg:grid-cols-4 gap-y-6 gap-x-8 py-8">
          {[
            ["25+", "Years of Excellence"],
            ["3000+", "Projects Delivered"],
            ["1000+", "Events"],
            ["2000+", "Clients"],
          ].map(([k, v]) => (
            <div key={v} className="min-w-0">
              <div className="font-display text-[22px] lg:text-[26px] font-medium tracking-tight text-white">
                {k}
              </div>
              <div className="mt-1.5 text-[11px] uppercase tracking-[0.22em] text-white/60">
                {t(v)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="pointer-events-none absolute bottom-[110px] right-8 hidden lg:flex flex-col items-center gap-3 opacity-0 animate-[heroFade_900ms_ease-out_1700ms_forwards]">
        <span className="text-[10px] uppercase tracking-[0.3em] text-white/60 [writing-mode:vertical-rl] rotate-180">
          {t("Scroll")}
        </span>
        <span className="block h-12 w-px bg-white/40 origin-top animate-[scrollLine_2.4s_ease-in-out_infinite]" />
      </div>
    </section>
  );
}


/* ---------------- Trusted By (icon marquee) ---------------- */

function TrustedBy() {
  const { t } = useLang();
  const partners: { logo: string; name: string }[] = [
    { logo: galfarLogo.url, name: "Galfar" },
    { logo: bobyLogo.url, name: "Boby Group" },
    { logo: dubaiHoldingLogo.url, name: "Dubai Holding" },
    { logo: globalVillageLogo.url, name: "Global Village" },
    { logo: jjLogo.url, name: "JJ & Sons" },
    { logo: royalKingLogo.url, name: "Royal & King" },
    { logo: malabarLogo.url, name: "Malabar Gold" },
    { logo: morickapLogo.url, name: "Morickap Jewels" },
    { logo: nishkaLogo.url, name: "Nishka" },
    { logo: rakPoliceLogo.url, name: "RAK Police" },
    { logo: shababLogo.url, name: "Shabab Al Ahli" },
    { logo: stsLogo.url, name: "STS" },
    { logo: vexusLogo.url, name: "Vexus Interiors" },
  ];
  const row = [...partners, ...partners];
  return (
    <section className="relative py-24 overflow-hidden">
      {/* ambient backdrop */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-br from-[color:var(--background)] via-card to-[color:var(--background)]" />
      <div className="absolute -z-10 top-10 left-1/4 h-72 w-72 rounded-full bg-primary/15 blur-3xl" />
      <div className="absolute -z-10 bottom-10 right-1/4 h-80 w-80 rounded-full bg-accent/20 blur-3xl" />

      <div className="container-editorial">
        <div className="relative rounded-3xl border border-white/40 bg-white/30 backdrop-blur-xl shadow-[0_20px_60px_-25px_rgba(0,0,0,0.25)] overflow-hidden">
          <div className="pointer-events-none absolute inset-0 rounded-3xl bg-gradient-to-b from-white/50 via-transparent to-transparent opacity-60" />

          <div className="relative flex flex-col items-center text-center gap-3 pt-12 pb-8 px-6">
            <Eyebrow>{t("Trusted By")}</Eyebrow>
            <p className="text-[15px] text-[color:var(--text-secondary)] max-w-[460px]">
              {t("Selected partners across the region.")}
            </p>
          </div>

          <div className="relative pb-12">
            <div className="pointer-events-none absolute inset-y-0 left-0 w-24 lg:w-40 z-10 bg-gradient-to-r from-white/60 to-transparent" />
            <div className="pointer-events-none absolute inset-y-0 right-0 w-24 lg:w-40 z-10 bg-gradient-to-l from-white/60 to-transparent" />
            <div className="flex w-max animate-marquee gap-6 lg:gap-8 will-change-transform px-6 items-center">
              {row.map(({ logo, name }, i) => (
                <div
                  key={`${name}-${i}`}
                  className="group flex items-center justify-center shrink-0 rounded-2xl border border-white/50 bg-white/70 backdrop-blur-md px-6 py-4 shadow-[0_8px_24px_-12px_rgba(0,0,0,0.2)] hover:bg-white hover:border-primary/30 transition-all duration-300 h-24 w-40"
                >
                  <img
                    src={logo}
                    alt={name}
                    loading="lazy"
                    className="max-h-16 max-w-full object-contain transition-transform group-hover:scale-105"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}


/* ---------------- Why FineLED ---------------- */

function WhyFineLED() {
  const { t } = useLang();
  const items = [
    { icon: Award, title: "Advanced display technology", body: "Superior brightness, stunning clarity, accurate colours and smooth, dependable performance, engineered over 25+ years of LED craftsmanship." },
    { icon: Cpu, title: "End-to-end LED solutions", body: "From consultation and design to installation, training and after-sales support, we manage every stage of your project with precision." },
    { icon: Volume2, title: "Integrated audio-visual technology", body: "Pixel-perfect LED paired with concert-grade audio, processing and control, tuned as one seamless system for venues, studios and stadiums." },
    { icon: ShieldCheck, title: "Guaranteed delivery & 24/7 support", body: "Fixed timelines, a single point of accountability and a regional support network across Oman, UAE and the GCC, with local engineers, spares and proactive monitoring." },
  ];
  return (
    <section id="why" className="bg-background py-[120px] lg:py-[160px]">
      <div className="container-editorial">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <Eyebrow>{t("Why FineLED")}</Eyebrow>
            <h2 className="display-lg mt-6">
              {t("A standard of finish set by architecture, not electronics.")}
            </h2>
          </div>
          <div className="lg:col-span-7 lg:pt-4">
            <p className="text-[18px] leading-[1.7] text-[color:var(--text-secondary)] max-w-[620px]">
              {t("We work with architects, developers and brands who measure quality in millimetres and decades. Every FineLED installation is treated as a permanent piece of the building it lives in.")}
            </p>
          </div>
        </div>

        <div className="mt-20 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map(({ icon: Icon, title, body }) => (
            <div
              key={title}
              className="lift-card lift-card-hover bg-card rounded-[18px] border border-border p-10"
            >
              <Icon className="h-7 w-7 text-secondary" strokeWidth={1.5} />
              <h3 className="mt-8 font-display text-[17px] font-medium tracking-tight leading-tight">
                {t(title)}
              </h3>
              <p className="mt-4 text-[15px] leading-[1.7] text-[color:var(--text-secondary)]">
                {t(body)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}


/* ---------------- About ---------------- */

function About({ variant = "home" }: { variant?: "home" | "detail" } = {}) {
  const { t } = useLang();
  const values = [
    { t: "Technological Innovation", long: "From fine-pitch indoor walls to weather-rated outdoor systems, we invest in R&D, calibration tooling and the latest driver IC generations so every install stays future-ready." },
    { t: "Respect & Integrity", long: "Clear scopes, honest timelines and transparent pricing. We say what we'll deliver, then deliver what we said, to clients, partners and our own team." },
    { t: "Sustainable Development", long: "Low-power LED modules, intelligent brightness control and recyclable cabinets, engineered to lower running cost and footprint over the full lifecycle." },
    { t: "Quality & Creativity", long: "Every brief is treated as a design problem first: curves, ceilings, transparencies and bespoke pixel pitches that turn a display into a brand moment." },
    { t: "Teamwork with Passion", long: "Engineers, designers and project managers working side-by-side, one accountable team from first site survey through to commissioning and aftercare." },
    { t: "Kaizen", long: "Post-project reviews, training cycles and field feedback loops keep our installation standards and service playbooks sharpening with every deployment." },
    { t: "Commitment to Excellence", long: "Dedicated account leads, 24/7 regional support and SLA-backed response times, because a display is only as good as the team standing behind it." },
  ];

  if (variant === "detail") {
    return (
      <section id="about" className="bg-[oklch(0.93_0.014_75)]">
        {/* Intro band */}
        <div className="container-editorial py-[100px] lg:py-[140px]">
          <div className="grid lg:grid-cols-12 gap-16">
            <div className="lg:col-span-7">
              <Eyebrow>{t("About FineLED")}</Eyebrow>
              <h2 className="display-lg mt-6 text-primary">
                {t("Engineering brightness")} <br />{t("for the region's most")} <br />{t("demanding spaces.")}
              </h2>
              <p className="mt-10 text-[17px] leading-[1.75] text-foreground/80 max-w-[620px]">
                {t("FineLED has emerged as a leading LED screen manufacturer and display supplier under Fine Arts Advertising LLC, Dubai. Headquartered in the UAE with over 25 years of experience in signage, graphic design, digital printing and digital marketing, we constantly evolve our capabilities around the latest technology and our clients' needs.")}
              </p>
              <p className="mt-5 text-[17px] leading-[1.75] text-foreground/70 max-w-[620px]">
                {t("In partnership with Al-Ajmi Partners Investments LLC in Oman, we serve clients across Oman, the UAE and all over the world, an established and most trusted supplier of LED screen displays and AV solutions in Oman, the UAE and the wider GCC.")}
              </p>
            </div>
            <div className="lg:col-span-5 lg:pt-6">
              <div className="overflow-hidden rounded-[18px] border border-border group h-full">
                <img
                  src={aboutLed}
                  alt="Macro detail of fine-pitch LED display pixels"
                  loading="lazy"
                  className="w-full h-[320px] lg:h-full min-h-[420px] object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-105"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Vision + Mission split band */}
        <div className="relative overflow-hidden bg-primary text-white">
          <div
            aria-hidden
            className="absolute inset-0 opacity-[0.06]"
            style={{
              backgroundImage:
                "linear-gradient(to right, rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.6) 1px, transparent 1px)",
              backgroundSize: "72px 72px",
            }}
          />
          <div
            aria-hidden
            className="absolute -top-40 -right-40 h-[520px] w-[520px] rounded-full opacity-30 blur-3xl"
            style={{ background: "radial-gradient(circle, var(--taupe), transparent 65%)" }}
          />
          <div className="container-editorial relative py-[110px] lg:py-[150px] grid lg:grid-cols-2 gap-16">
            {[
              {
                n: "01",
                label: "Vision",
                body:
                  "To brighten the global market with high-quality advertisements powered by perfect LED displays, energy-efficient and eco-friendly by design.",
              },
              {
                n: "02",
                label: "Mission",
                body:
                  "To provide superior-quality LED display solutions with ensured brightness and creativity that help our clients advertise their products and services, effectively.",
              },
            ].map((v) => (
              <div key={v.n} className="relative">
                <div className="font-display text-[96px] lg:text-[128px] leading-none tracking-tight text-[color:var(--taupe)]/40">
                  {v.n}
                </div>
                <div className="eyebrow !text-[color:var(--taupe)] mt-4">{t(v.label)}</div>
                <p className="mt-6 font-display text-[26px] lg:text-[32px] leading-[1.25] tracking-tight text-white max-w-[560px]">
                  {t(v.body)}
                </p>
                <div className="mt-8 h-px w-24 bg-[color:var(--taupe)]/60" />
              </div>
            ))}
          </div>
        </div>

        {/* Core Values manifesto grid */}
        <div className="container-editorial py-[110px] lg:py-[150px]">
          <div className="max-w-[720px]">
            <Eyebrow>{t("Our Core Values")}</Eyebrow>
            <h3 className="display-md mt-6 text-primary">
              {t("Seven principles.")} <br /> {t("One way of working.")}
            </h3>
          </div>
          <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {values.map((v, i) => (
              <div
                key={v.t}
                className="lift-card lift-card-hover group relative overflow-hidden rounded-[18px] border border-border bg-card p-8"
              >
                <div
                  aria-hidden
                  className="pointer-events-none absolute -top-24 -right-24 h-48 w-48 rounded-full opacity-0 blur-3xl transition-opacity duration-700 group-hover:opacity-40"
                  style={{ background: "radial-gradient(circle, var(--primary), transparent 65%)" }}
                />
                <div className="relative flex items-baseline justify-between">
                  <div className="font-display text-[13px] tracking-[0.28em] uppercase text-[color:var(--taupe)]">
                    {String(i + 1).padStart(2, "0")}
                  </div>
                  <div className="font-display text-[44px] leading-none text-primary/[0.06] transition-colors duration-500 group-hover:text-primary/20">
                    0{i + 1}
                  </div>
                </div>
                <h4 className="relative mt-5 font-display text-[19px] font-medium tracking-tight text-primary leading-snug">
                  {t(v.t)}
                </h4>
                <div className="relative mt-5 h-px w-10 bg-primary/20 transition-all duration-500 group-hover:w-20 group-hover:bg-primary" />
                <p className="relative mt-5 text-[14px] leading-[1.7] text-[color:var(--text-secondary)]">
                  {t(v.long)}
                </p>
              </div>
            ))}

            {/* Closing statement tile — fills the 8th slot, keeps the grid balanced */}
            <div className="group md:col-span-2 relative overflow-hidden rounded-[18px] border border-primary/20 bg-gradient-to-br from-primary via-primary to-secondary text-white p-8 lg:p-10 flex flex-col md:flex-row md:items-center gap-8 transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_40px_80px_-25px_rgba(86,28,36,0.55)] hover:border-[color:var(--taupe)]/50">
              {/* Sheen sweep on hover */}
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-[1400ms] ease-out"
                style={{
                  background:
                    "linear-gradient(115deg, transparent 40%, rgba(255,255,255,0.14) 50%, transparent 60%)",
                }}
              />
              <div
                aria-hidden
                className="absolute inset-0 opacity-[0.08]"
                style={{
                  backgroundImage:
                    "linear-gradient(to right, rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.6) 1px, transparent 1px)",
                  backgroundSize: "48px 48px",
                }}
              />
              <div
                aria-hidden
                className="absolute -bottom-24 -right-24 h-64 w-64 rounded-full opacity-40 blur-3xl"
                style={{ background: "radial-gradient(circle, var(--taupe), transparent 65%)" }}
              />
              <div className="relative flex-1">
                <div className="font-display text-[13px] tracking-[0.28em] uppercase text-[color:var(--taupe)]">
                  {t("The Promise")}
                </div>
                <h4 className="mt-5 font-display text-[24px] lg:text-[28px] leading-[1.2] tracking-tight text-white">
                  {t("Seven principles. One way of working.")}
                </h4>
                <div className="mt-5 h-px w-10 bg-[color:var(--taupe)]/70" />
                <p className="mt-5 text-[14px] lg:text-[15px] leading-[1.7] text-white/85 max-w-[520px]">
                  {t("Every project we deliver carries the same discipline: precision engineering, transparent process and a team that stays with you long after installation.")}
                </p>
              </div>
              <a
                href="/quote"
                className="group relative shrink-0 inline-flex items-center justify-center gap-2 h-12 px-6 rounded-[12px] border border-white/70 bg-white text-primary font-display text-[13px] tracking-[0.22em] uppercase shadow-[0_10px_30px_-10px_rgba(0,0,0,0.35)] hover:bg-[color:var(--taupe)] hover:text-primary hover:border-[color:var(--taupe)] hover:shadow-[0_18px_44px_-12px_rgba(214,170,140,0.55)] hover:-translate-y-0.5 transition-all duration-300"
              >
                {t("Start a project")}
                <span aria-hidden className="transition-transform duration-300 group-hover:translate-x-1">→</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="about" className="bg-[oklch(0.93_0.014_75)] py-[120px] lg:py-[160px]">
      <div className="container-editorial">
        <div className="grid lg:grid-cols-12 gap-16">
          <div className="lg:col-span-7">
            <Eyebrow>{t("About FineLED")}</Eyebrow>
            <h2 className="display-lg mt-6 text-primary">
              {t("Engineering brightness")} <br />{t("for the region's most")} <br />{t("demanding spaces.")}
            </h2>
            <p className="mt-10 text-[17px] leading-[1.75] text-foreground/80 max-w-[620px]">
              {t("FineLED has emerged as a leading LED screen manufacturer and display supplier under Fine Arts Advertising LLC, Dubai. Headquartered in the UAE with over 25 years of experience in signage, graphic design, digital printing and digital marketing, we constantly evolve our capabilities around the latest technology and our clients' needs.")}
            </p>
            <p className="mt-5 text-[17px] leading-[1.75] text-foreground/70 max-w-[620px]">
              {t("In partnership with Al-Ajmi Partners Investments LLC in Oman, we serve clients across Oman, the UAE and all over the world, an established and most trusted supplier of LED screen displays and AV solutions in Oman, the UAE and the wider GCC.")}
            </p>
            <div className="mt-12 flex flex-wrap gap-4">
              <Btn href="#contact">
                {t("Talk to our team")} <ArrowRight className="h-4 w-4 rtl:-scale-x-100" />
              </Btn>
              <Btn variant="secondary" href="#projects">
                {t("Featured Work")}
              </Btn>
            </div>
            <div className="mt-16 overflow-hidden rounded-[18px] border border-border group">
              <img
                src={aboutLed}
                alt="Macro detail of fine-pitch LED display pixels"
                loading="lazy"
                width={1600}
                height={1100}
                className="w-full h-[280px] lg:h-[420px] object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-105"
              />
            </div>
          </div>
          <div className="lg:col-span-5 lg:pt-6 grid gap-6">
            <div className="bg-card rounded-[18px] border border-border p-10">
              <div className="eyebrow">{t("Vision")}</div>
              <p className="mt-4 font-display text-[18px] font-medium tracking-tight leading-snug text-primary">
                {t("To brighten the global market with high-quality advertisements powered by perfect LED displays, energy-efficient and eco-friendly by design.")}
              </p>
            </div>
            <div className="bg-card rounded-[18px] border border-border p-10">
              <div className="eyebrow">{t("Mission")}</div>
              <p className="mt-4 font-display text-[18px] font-medium tracking-tight leading-snug text-primary">
                {t("To provide superior-quality LED display solutions with ensured brightness and creativity that help our clients advertise their products and services, effectively.")}
              </p>
            </div>
            <div className="bg-card rounded-[18px] border border-border p-10">
              <div className="eyebrow mb-6">{t("Our Core Values")}</div>
              <ul className="divide-y divide-border">
                {values.map((v) => (
                  <li key={v.t} className="group/value py-3.5 first:pt-0 last:pb-0 cursor-pointer">
                    <div className="font-display text-[15px] font-medium tracking-tight text-primary transition-colors group-hover/value:text-[color:var(--wine)]">
                      {t(v.t)}
                    </div>
                    <div className="grid grid-rows-[0fr] group-hover/value:grid-rows-[1fr] transition-[grid-template-rows] duration-500 ease-out">
                      <div className="overflow-hidden">
                        <p className="mt-2 text-[13px] leading-[1.65] text-[color:var(--text-secondary)] opacity-0 group-hover/value:opacity-100 transition-opacity duration-500 delay-75">
                          {t(v.long)}
                        </p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}



/* ---------------- Solutions ---------------- */

function Solutions() {
  const { t } = useLang();
  const items = [
    { n: "01", img: solIndoor, t: "Indoor Fine-Pitch LED", d: "Seamless, calibrated walls for lobbies, control rooms and command centres.", slug: "indoor-led-display" },
    { n: "02", img: solOutdoor, t: "Outdoor Architectural", d: "Weather-rated, building-integrated displays designed to perform for years.", slug: "outdoor-led-display" },
    { n: "03", img: solCreative, t: "Creative & Curved", d: "Custom radii, ceilings, columns and sculptural forms engineered to brief.", slug: "flexible-led-display" },
    { n: "04", img: solTransparent, t: "Transparent & Mesh", d: "Glass-integrated visuals that preserve sightlines and daylight.", slug: "transparent-led-display" },
    { n: "05", img: solRental, t: "Rental & Touring", d: "Event-grade systems with rapid deployment and tour-ready logistics.", slug: "rental-led-screen" },
    { n: "06", img: solControl, t: "Control & Content", d: "Processors, scheduling, monitoring and creative content services.", slug: "interactive-digital-kiosk" },
  ];
  return (
    <section id="solutions" className="bg-card py-[120px] lg:py-[160px]">
      <div className="container-editorial">
        <div className="grid lg:grid-cols-12 gap-12 items-end">
          <div className="lg:col-span-8">
            <Eyebrow>{t("Solutions")}</Eyebrow>
            <h2 className="display-lg mt-6 max-w-[820px]">
              {t("Six disciplines. One standard of finish.")}
            </h2>
          </div>
          <div className="lg:col-span-4 lg:text-right rtl:lg:text-left">
            <Link
              to="/products"
              className="inline-flex items-center gap-2 text-[14px] font-medium tracking-wide text-secondary hover:text-primary"
            >
              {t("View all products")} <ArrowRight className="h-4 w-4 rtl:-scale-x-100" />
            </Link>
          </div>
        </div>

        <div className="mt-20 grid md:grid-cols-2 lg:grid-cols-3 gap-7">
          {items.map((it) => (
            <Link
              key={it.n}
              to="/products/$slug"
              params={{ slug: it.slug }}
              className="group relative overflow-hidden rounded-[20px] border border-border bg-card transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_30px_60px_-20px_rgba(86,28,36,0.28)]"
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-accent">
                <img
                  src={it.img}
                  alt={t(it.t)}
                  loading="lazy"
                  width={1280}
                  height={960}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/10 to-transparent opacity-90 transition-opacity duration-500 group-hover:opacity-100" />
                <div className="absolute inset-x-0 top-0 flex items-start justify-between p-5">
                  <span className="font-display text-[12px] tracking-[0.22em] uppercase text-white/90 backdrop-blur-md bg-black/25 border border-white/20 rounded-full px-3 py-1">
                    {it.n}
                  </span>
                  <span className="h-9 w-9 grid place-items-center rounded-full backdrop-blur-md bg-white/15 border border-white/30 text-white transition-transform duration-500 group-hover:rotate-45">
                    <ArrowUpRight className="h-4 w-4 rtl:-scale-x-100" />
                  </span>
                </div>
                <h3 className="absolute left-5 right-5 bottom-5 font-display text-[20px] lg:text-[22px] font-medium tracking-tight leading-tight text-white">
                  {t(it.t)}
                </h3>
              </div>
              <div className="p-7 lg:p-8">
                <p className="text-[15px] leading-[1.7] text-[color:var(--text-secondary)] max-w-[360px]">
                  {t(it.d)}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Industries ---------------- */

function Industries() {
  const { t } = useLang();
  const items = [
    { icon: ShoppingBag, t: "Retail & Shopping Malls" },
    { icon: Sparkles, t: "Hospitality & Hotels" },
    { icon: Building2, t: "Corporate Offices" },
    { icon: ShieldCheck, t: "Government & Smart Cities" },
    { icon: Plane, t: "Transportation & Airports" },
    { icon: Trophy, t: "Sports & Stadiums" },
    { icon: Globe2, t: "Events & Exhibitions" },
    { icon: Cpu, t: "Broadcast & Media" },
  ];
  return (
    <section id="industries" className="bg-[oklch(0.93_0.014_75)] py-[120px] lg:py-[160px]">
      <div className="container-editorial">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <Eyebrow>{t("Industries")}</Eyebrow>
            <h2 className="display-lg mt-6 text-primary">
              {t("Trusted by the sectors that don't allow for compromise.")}
            </h2>
          </div>
          <div className="lg:col-span-7 grid sm:grid-cols-2 gap-6">
            {items.map(({ icon: Icon, t: label }) => {
              return (
                <div
                  key={label}
                  className="lift-card lift-card-hover bg-card rounded-[18px] border border-border p-10 flex items-center gap-6"
                >
                  <Icon className="h-7 w-7 text-secondary shrink-0" strokeWidth={1.5} />
                  <span className="font-display text-[20px] font-medium tracking-tight leading-tight text-primary">
                    {t(label)}
                  </span>
                </div>
              );
            })}
          </div>

        </div>
      </div>
    </section>
  );
}

/* ---------------- Projects ---------------- */

function Projects() {
  const { t } = useLang();
  const items = [
    { img: projBillboard, tag: "Outdoor · Dubai", t: "Sheikh Zayed Tower Façade", d: "A 2,400 sqm building-integrated façade engineered to broadcast at boulevard scale." },
    { img: projMall, tag: "Retail · Abu Dhabi", t: "Yas Atrium Centerpiece", d: "A suspended centrepiece display that anchors the mall's flagship atrium." },
    { img: projAirport, tag: "Transport · Muscat", t: "International Terminal FIDS", d: "Calibrated information displays across departures, arrivals and lounges." },
    { img: projHotel, tag: "Hospitality · DIFC", t: "The Lobby Art Wall", d: "A floor-to-ceiling kinetic art surface, curated to the property's aesthetic." },
  ];
  return (
    <section id="projects" className="bg-card py-[120px] lg:py-[160px]">
      <div className="container-editorial">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8">
          <div className="max-w-[680px]">
            <Eyebrow>{t("Featured Projects")}</Eyebrow>
            <h2 className="display-lg mt-6">{t("Selected work, across the region.")}</h2>
          </div>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 text-[14px] font-medium tracking-wide text-secondary hover:text-primary"
          >
            {t("All case studies")} <ArrowRight className="h-4 w-4 rtl:-scale-x-100" />
          </a>
        </div>

        <div className="mt-20 grid lg:grid-cols-2 gap-10 lg:gap-12">
          {items.map((p, i) => (
            <article
              key={p.t}
              className={`group ${i % 2 === 1 ? "lg:mt-24" : ""}`}
            >
              <div className="overflow-hidden rounded-[18px] border border-border bg-accent">
                <img
                  src={p.img}
                  alt={p.t}
                  loading="lazy"
                  width={1280}
                  height={900}
                  className="w-full h-[420px] lg:h-[520px] object-cover transition-transform duration-700 group-hover:scale-[1.03]"
                />
              </div>
              <div className="mt-8 flex items-start justify-between gap-6">
                <div className="min-w-0">
                  <div className="text-[12px] uppercase tracking-[0.18em] text-[color:var(--text-secondary)]">
                    {t(p.tag)}
                  </div>
                  <h3 className="mt-3 font-display text-[20px] font-medium tracking-tight leading-tight">
                    {t(p.t)}
                  </h3>
                  <p className="mt-3 text-[15px] leading-[1.7] text-[color:var(--text-secondary)] max-w-[520px]">
                    {t(p.d)}
                  </p>
                </div>
                <ArrowUpRight className="h-6 w-6 shrink-0 text-secondary transition-transform group-hover:-translate-y-1 group-hover:translate-x-1 rtl:-scale-x-100" />
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Process ---------------- */

function Process() {
  const { t } = useLang();
  const steps: [string, string, string][] = [
    ["01", "Consult", "We learn the building, brief and brand before specifying anything."],
    ["02", "Design", "Engineering drawings, mock-ups and content tests aligned to architecture."],
    ["03", "Build", "Calibrated panels, structural integration and clean cable architecture."],
    ["04", "Care", "Monitoring, spares and 24/7 engineering for the life of the installation."],
  ];
  return (
    <section className="bg-background py-[120px] lg:py-[160px]">
      <div className="container-editorial">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <Eyebrow>{t("Delivery Process")}</Eyebrow>
            <h2 className="display-lg mt-6">{t("Four stages. One accountable team.")}</h2>
          </div>
          <div className="lg:col-span-7 lg:pt-4">
            <p className="text-[18px] leading-[1.7] text-[color:var(--text-secondary)] max-w-[620px]">
              {t("FineLED owns the entire chain, from the first site visit to the last firmware update. No hand-offs, no surprises, no untraceable issues.")}
            </p>
          </div>
        </div>
        <div className="mt-20 grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map(([n, title, d]) => (
            <div key={n} className="lift-card lift-card-hover bg-card rounded-[18px] border border-border p-10 lg:p-12">
              <div className="font-display text-[14px] tracking-widest text-[color:var(--text-secondary)]">
                {n}
              </div>
              <h3 className="mt-12 font-display text-[19px] font-medium tracking-tight">{t(title)}</h3>
              <p className="mt-4 text-[15px] leading-[1.7] text-[color:var(--text-secondary)]">
                {t(d)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Promise + Stats (dark band) ---------------- */

function PromiseStats() {
  const { t } = useLang();
  return (
    <section className="bg-primary text-white py-[120px] lg:py-[160px]">
      <div className="container-editorial">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <div className="eyebrow !text-[color:var(--taupe)]">{t("The FineLED Promise")}</div>
            <h2 className="display-lg mt-6 text-white">
              {t("We deliver displays our clients never think about, only enjoy.")}
            </h2>
            <p className="mt-8 text-[18px] leading-[1.7] text-white/70 max-w-[520px]">
              {t("A finished installation is the start of the relationship. We monitor, maintain and evolve your display so it stays as precise on year ten as on day one.")}
            </p>
            <div className="mt-12 flex flex-wrap gap-4">
              <Btn href="#contact" variant="ghost-light">
                {t("Request Proposal")} <ArrowRight className="h-4 w-4 rtl:-scale-x-100" />
              </Btn>
            </div>
          </div>
          <div className="lg:col-span-7 grid grid-cols-2 gap-y-16 gap-x-8 lg:pl-12 rtl:lg:pl-0 rtl:lg:pr-12">
            {[
              ["3000+", "Projects delivered"],
              ["1000+", "Events"],
              ["2000+", "Clients"],
              ["25+", "Years of excellence"],
            ].map(([k, v]) => (
              <div key={v} className="border-t border-white/20 pt-6">
                <div className="display-stat !text-[color:var(--taupe)]">{k}</div>
                <div className="mt-4 text-[13px] uppercase tracking-[0.18em] text-white/70">
                  {t(v)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Testimonials ---------------- */

function Testimonials() {
  const { t } = useLang();
  const quotes = [
    {
      q: "FineLED is the only LED partner we trust on flagship sites. The finish is architectural, not industrial.",
      a: "Principal Architect",
      c: "International Design Studio, Dubai",
    },
    {
      q: "Three years on, the wall still calibrates to the day-one reference. That has never happened with any other vendor.",
      a: "Director of Operations",
      c: "Hospitality Group, Muscat",
    },
  ];
  return (
    <section className="relative isolate overflow-hidden bg-[oklch(0.20_0.012_40)] py-[120px] lg:py-[160px]">
      {/* warm vignette */}
      <div
        className="absolute inset-0 -z-10 opacity-70"
        style={{
          background:
            "radial-gradient(60% 55% at 75% 40%, rgba(109,41,50,0.55), transparent 70%), radial-gradient(50% 50% at 15% 85%, rgba(86,28,36,0.45), transparent 70%)",
        }}
      />
      {/* floating particles */}
      <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-[18%] left-[10%] h-2 w-2 rounded-full bg-[color:var(--taupe)]/60 blur-[1px] animate-float" />
        <div
          className="absolute bottom-[22%] right-[15%] h-2.5 w-2.5 rounded-full bg-[color:var(--taupe)]/40 blur-[1px] animate-float"
          style={{ animationDelay: "1.2s" }}
        />
        <div
          className="absolute top-[55%] left-[40%] h-1.5 w-1.5 rounded-full bg-white/25 blur-[1px] animate-float"
          style={{ animationDelay: "2s" }}
        />
      </div>

      <div className="container-editorial">
        <div className="eyebrow !text-[color:var(--taupe)]">{t("What clients say")}</div>
        <h2 className="display-lg mt-6 text-white max-w-[720px]">
          {t("Trusted on the region's most demanding installations.")}
        </h2>

        <div className="mt-14 grid lg:grid-cols-2 gap-8 lg:gap-10">
          {quotes.map((q) => (
            <figure
              key={q.a}
              className="rounded-[24px] border border-white/15 bg-white/[0.06] backdrop-blur-xl p-8 lg:p-10 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.5)] transition-all duration-500 hover:bg-white/[0.09] hover:border-white/30 hover:-translate-y-1"
            >
              <Quote className="h-7 w-7 text-[color:var(--taupe)]" strokeWidth={1.5} />
              <blockquote className="mt-5 font-display text-[18px] lg:text-[22px] leading-[1.45] tracking-tight text-white/95">
                "{t(q.q)}"
              </blockquote>
              <figcaption className="mt-8 pt-6 border-t border-white/15">
                <div className="font-display text-[16px] font-medium text-white">{t(q.a)}</div>
                <div className="text-[12px] tracking-wide text-white/60 mt-1">{t(q.c)}</div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}


/* ---------------- Leadership ---------------- */

function Team() {
  const { t } = useLang();
  const stats: [string, string][] = [
    ["25+", "Years of excellence"],
    ["3000+", "Projects delivered"],
    ["1000+", "Events"],
    ["2000+", "Clients"],
  ];
  return (
    <section id="team" className="bg-background py-[120px] lg:py-[160px]">
      <div className="container-editorial">
        <Reveal>
          <div className="grid lg:grid-cols-12 gap-12 items-end">
            <div className="lg:col-span-7">
              <Eyebrow>{t("The People")}</Eyebrow>
              <h2 className="display-lg mt-6">
                {t("One team.")} <br />
                {t("Every project, end to end.")}
              </h2>
            </div>
            <div className="lg:col-span-5 lg:pb-3">
              <p className="text-[16px] leading-[1.75] text-[color:var(--text-secondary)] max-w-[480px]">
                {t("Our consultants, hardware engineers, software specialists and installation crews are fully responsible for your digital signage project, from first consultancy through hardware, software configuration and ongoing technical support.")}
              </p>
            </div>
          </div>
        </Reveal>

        {/* Group photo */}
        <Reveal delay={120}>
          <figure className="mt-16 lg:mt-20 overflow-hidden rounded-[20px] border border-border bg-accent group">
            <img
              src={teamGroup.url}
              alt="The FineLED team on stage at a client installation event in the UAE"
              loading="lazy"
              className="w-full h-[360px] sm:h-[460px] lg:h-[640px] object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-[1.03]"
            />
            <figcaption className="px-6 lg:px-10 py-5 flex flex-wrap items-center justify-between gap-4 bg-card border-t border-border">
              <span className="text-[13px] text-[color:var(--text-secondary)]">
                {t("FineLED team on site, Ras Al Khaimah Police installation handover.")}
              </span>
              <span className="text-[11px] uppercase tracking-[0.22em] text-[color:var(--wine)]">
                {t("UAE · 2025")}
              </span>
            </figcaption>
          </figure>
        </Reveal>

        {/* Team stats */}
        <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map(([k, v], i) => (
            <Reveal key={v} delay={i * 90}>
              <div className="lift-card lift-card-hover bg-card rounded-[18px] border border-border p-8 lg:p-10 h-full">
                <div className="font-display text-[36px] lg:text-[44px] font-medium tracking-tight text-primary leading-none">
                  {k}
                </div>
                <div className="mt-4 text-[13px] leading-[1.6] text-[color:var(--text-secondary)] max-w-[220px]">
                  {t(v)}
                </div>
              </div>
            </Reveal>
          ))}
        </div>


        {/* Founder quote */}
        <div className="mt-24 lg:mt-32 relative isolate overflow-hidden rounded-[28px] border border-[color:var(--wine)]/20 bg-gradient-to-br from-[color:var(--wine)] via-[oklch(0.22_0.04_25)] to-[oklch(0.18_0.02_30)] p-10 lg:p-16 shadow-[0_40px_100px_-30px_rgba(86,28,36,0.55)]">
          {/* warm vignette */}
          <div
            className="absolute inset-0 -z-10 opacity-80 pointer-events-none"
            style={{
              background:
                "radial-gradient(60% 55% at 80% 30%, rgba(214,170,140,0.18), transparent 70%), radial-gradient(50% 50% at 10% 90%, rgba(109,41,50,0.55), transparent 70%)",
            }}
          />
          {/* oversized accent quote */}
          <div className="pointer-events-none absolute -top-6 right-6 lg:right-12 font-display text-[200px] lg:text-[280px] leading-none text-white/[0.06] select-none">
            "
          </div>

          <div className="grid lg:grid-cols-12 gap-10 lg:gap-12 items-center">
            <div className="lg:col-span-4">
              <div className="eyebrow !text-[color:var(--taupe)]">{t("From the founder")}</div>
              <div className="mt-8 flex items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-gradient-to-br from-[color:var(--taupe)] to-[color:var(--wine)] text-white grid place-items-center font-display text-[22px] font-medium border border-white/25 shadow-[0_10px_30px_rgba(0,0,0,0.4)]">
                  F
                </div>
                <div>
                  <div className="font-display text-[17px] font-medium text-white">
                    {t("FineLED Leadership")}
                  </div>
                  <div className="text-[12px] tracking-wide text-white/60 mt-1">
                    {t("Fine Arts Advertising LLC")}
                  </div>
                </div>
              </div>
              <div className="mt-8 inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/[0.06] backdrop-blur-md px-4 py-2">
                <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--taupe)]" />
                <span className="text-[11px] uppercase tracking-[0.22em] text-white/80">
                  {t("Est. 2004 · Dubai")}
                </span>
              </div>
            </div>
            <div className="lg:col-span-8 relative">
              <Quote className="h-8 w-8 text-[color:var(--taupe)]" strokeWidth={1.5} />
              <p className="mt-6 font-display text-[20px] lg:text-[26px] font-medium leading-[1.35] tracking-tight text-white/95 max-w-[820px]">
                {t(
                  "\"We started FineLED because the region deserved an LED partner that treated every installation like a permanent piece of the building. Twenty years on, that is still the only standard we measure ourselves against.\"",
                )}
              </p>
              <div className="mt-8 h-px w-24 bg-gradient-to-r from-[color:var(--taupe)] to-transparent" />
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}

/* ---------------- FAQ ---------------- */

function FAQItem({ q, a, defaultOpen = false }: { q: string; a: string; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-t border-border py-8">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full grid grid-cols-[minmax(0,1fr)_auto] items-center gap-6 text-left rtl:text-right"
      >
        <span className="font-display text-[20px] lg:text-[24px] font-medium tracking-tight">
          {q}
        </span>
        <span className="shrink-0 flex h-10 w-10 items-center justify-center rounded-full border border-border text-secondary">
          {open ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
        </span>
      </button>
      {open && (
        <p className="mt-6 max-w-[760px] text-[16px] leading-[1.75] text-[color:var(--text-secondary)] animate-fade-up">
          {a}
        </p>
      )}
    </div>
  );
}

function FAQ() {
  const { t } = useLang();
  const items = [
    { q: "Which regions does FineLED operate in?", a: "We deliver across the GCC with primary operations in the UAE and the Sultanate of Oman, supported by a regional engineering and logistics network.", defaultOpen: true },
    { q: "What pixel pitch should I choose?", a: "Pitch depends on viewing distance, content and ambient light. Our consultants specify the right indoor fine-pitch or outdoor high-brightness panel after a site survey." },
    { q: "Do you provide installation and maintenance?", a: "Yes. Every project is delivered by our own engineers, with proactive monitoring, regional spare parts, scheduled calibration and 24/7 response after handover." },
    { q: "How long does a typical project take?", a: "From kickoff to handover, most projects complete in 8 to 16 weeks depending on scale, structural integration and content scope. We always commit to a fixed timeline." },
    { q: "Can displays operate in GCC weather conditions?", a: "Our outdoor systems are weather-rated for sustained heat, humidity, dust and sun load, with intelligent brightness control and thermal management built in." },
    { q: "Do you provide content management solutions?", a: "Yes, we supply processors, scheduling, monitoring and creative content services so your display stays as compelling on year ten as on day one." },
  ];
  return (
    <section id="resources" className="bg-background py-[120px] lg:py-[160px]">
      <div className="container-editorial grid lg:grid-cols-12 gap-12">
        <div className="lg:col-span-4">
          <Eyebrow>{t("Frequently asked")}</Eyebrow>
          <h2 className="display-lg mt-6">{t("Answers, not specifications.")}</h2>
        </div>
        <div className="lg:col-span-8">
          {items.map((it) => (
            <FAQItem key={it.q} q={t(it.q)} a={t(it.a)} defaultOpen={it.defaultOpen} />
          ))}
          <div className="border-t border-border" />
        </div>
      </div>
    </section>
  );
}

/* ---------------- Offices ---------------- */

function Offices() {
  const { t } = useLang();
  const offices = [
    {
      tag: "UAE Office",
      name: "FineLED, Best LED Screen Suppliers in Dubai",
      address: ["No. 9, 4th Street, Al-Khabaisi", "Abu-Bakr Metro Station Exit 1", "Dubai, United Arab Emirates"],
      phones: ["048 923 576", "+971 50 4235 194"],
      email: "contact@fineledscreen.com",
    },
    {
      tag: "Oman Office",
      name: "Fine Arts Advertising LLC",
      address: ["Muscat, Sultanate of Oman"],
      phones: ["+968 9403 8855", "+971 50 4235 194"],
      email: "accounts@fineledscreen.com",
    },
  ];
  return (
    <section
      id="offices"
      className="relative isolate overflow-hidden bg-primary text-white py-[120px] lg:py-[160px]"
    >
      {/* ambient burgundy + taupe glow field */}
      <div
        className="absolute inset-0 -z-10 opacity-90"
        style={{
          background:
            "radial-gradient(55% 50% at 18% 25%, rgba(214,170,140,0.28), transparent 70%), radial-gradient(50% 55% at 85% 80%, rgba(109,41,50,0.55), transparent 70%), radial-gradient(40% 40% at 50% 50%, rgba(86,28,36,0.35), transparent 75%)",
        }}
      />
      <div
        className="pointer-events-none absolute inset-0 -z-10 opacity-[0.07] mix-blend-overlay"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.6) 1px, transparent 1px)",
          backgroundSize: "48px 48px",
        }}
      />

      <div className="container-editorial relative">
        <div className="grid lg:grid-cols-12 gap-12 items-end">
          <div className="lg:col-span-7">
            <div className="eyebrow !text-[color:var(--taupe)]">{t("Our Offices")}</div>
            <h2 className="display-lg mt-6 text-white">
              {t("Two regional hubs.")} <br />
              {t("One accountable team.")}
            </h2>
          </div>
          <div className="lg:col-span-5 lg:pb-3">
            <p className="text-[16px] leading-[1.75] text-white/75 max-w-[480px]">
              {t("Engineering, project management and 24/7 lifecycle support, anchored in Dubai and Muscat, serving clients across the GCC and beyond.")}
            </p>
          </div>
        </div>

        <div className="mt-20 grid md:grid-cols-2 gap-7">
          {offices.map((o) => (
            <article
              key={o.tag}
              className="group relative overflow-hidden rounded-[24px] border border-white/20 bg-white/[0.07] backdrop-blur-xl p-10 lg:p-12 shadow-[0_30px_80px_-30px_rgba(0,0,0,0.55)] transition-all duration-500 hover:-translate-y-1 hover:border-white/35 hover:bg-white/[0.10] hover:shadow-[0_40px_100px_-30px_rgba(0,0,0,0.65)]"
            >
              {/* top sheen */}
              <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/40 to-transparent" />
              {/* hover glow */}
              <div className="pointer-events-none absolute -top-32 -right-32 h-72 w-72 rounded-full bg-[radial-gradient(circle_at_center,rgba(214,170,140,0.45),transparent_65%)] opacity-0 group-hover:opacity-100 transition-opacity duration-700" />

              <div className="relative flex items-start justify-between gap-6">
                <div className="eyebrow !text-[color:var(--taupe)]">{t(o.tag)}</div>
                <span className="h-10 w-10 grid place-items-center rounded-full bg-white/10 border border-white/25 backdrop-blur-md">
                  <MapPin className="h-4 w-4 text-[color:var(--taupe)]" strokeWidth={1.5} />
                </span>
              </div>

              <h3 className="relative mt-6 font-display text-[22px] lg:text-[26px] font-medium tracking-tight leading-tight text-white">
                {t(o.name)}
              </h3>

              <div className="relative mt-10 grid gap-7 border-t border-white/15 pt-8">
                <div>
                  <div className="text-[11px] uppercase tracking-[0.22em] text-[color:var(--taupe)]">
                    {t("Address")}
                  </div>
                  <address className="mt-3 not-italic text-[15px] leading-[1.7] text-white/85">
                    {o.address.map((line) => (
                      <div key={line}>{t(line)}</div>
                    ))}
                  </address>
                </div>

                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <div className="text-[11px] uppercase tracking-[0.22em] text-[color:var(--taupe)]">
                      {t("Phone")}
                    </div>
                    <ul className="mt-3 space-y-1.5">
                      {o.phones.map((p) => (
                        <li key={p}>
                          <a
                            href={`tel:${p.replace(/\s+/g, "")}`}
                            className="inline-flex items-center gap-2 text-[15px] text-white/85 hover:text-white transition-colors"
                          >
                            <Phone className="h-3.5 w-3.5 text-[color:var(--taupe)]" />
                            {p}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div className="text-[11px] uppercase tracking-[0.22em] text-[color:var(--taupe)]">
                      {t("Email")}
                    </div>
                    <a
                      href={`mailto:${o.email}`}
                      className="mt-3 inline-flex items-center gap-2 text-[15px] text-white/85 hover:text-white transition-colors break-all"
                    >
                      <Mail className="h-3.5 w-3.5 text-[color:var(--taupe)]" />
                      {o.email}
                    </a>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Final CTA ---------------- */


function FinalCTA() {
  const { t } = useLang();
  return (
    <section id="contact" className="bg-card py-[120px] lg:py-[160px]">
      <div className="container-editorial">
        <div className="rounded-[24px] bg-primary text-white p-12 lg:p-24">
          <div className="grid lg:grid-cols-12 gap-12 items-end">
            <div className="lg:col-span-8">
              <div className="eyebrow !text-[color:var(--taupe)]">{t("Begin a project")}</div>
              <h2 className="display-lg mt-6 text-white max-w-[820px]">
                {t("Tell us about the space. We'll tell you what's possible.")}
              </h2>
              <p className="mt-8 text-[18px] leading-[1.7] text-white/70 max-w-[560px]">
                {t("A short conversation is the fastest way to understand whether FineLED is the right partner for your installation.")}
              </p>
            </div>
            <div className="lg:col-span-4 flex flex-col gap-4 lg:items-end rtl:lg:items-start">
              <Btn href="mailto:hello@fineled.com" variant="ghost-light">
                {t("Request Proposal")} <ArrowRight className="h-4 w-4 rtl:-scale-x-100" />
              </Btn>
              <a
                href="tel:+97100000000"
                className="text-[14px] text-white/70 hover:text-white inline-flex items-center gap-2"
              >
                <Phone className="h-4 w-4" /> +971 0 000 0000
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- Parallax Sticky Showcase ---------------- */

function ParallaxShowcase() {
  const { t } = useLang();
  const panels: { img: string; eyebrow: string; title: string; body: string }[] = [
    {
      img: solOutdoor,
      eyebrow: "01 · Architecture",
      title: "Facades that broadcast at boulevard scale.",
      body: "Weather-rated, structurally-integrated LED skins engineered to become part of the building itself, calibrated to the light of the region.",
    },
    {
      img: solIndoor,
      eyebrow: "02 · Interiors",
      title: "Fine-pitch canvases for lobbies, studios and command rooms.",
      body: "Seamless indoor walls with reference-grade colour, low latency and finishes that match the joinery, not the electronics rack.",
    },
    {
      img: solCreative,
      eyebrow: "03 · Creative",
      title: "Curved, transparent, kinetic. Built to brief.",
      body: "Custom radii, ceilings, columns and sculptural forms, engineered from the pixel up so the display feels inevitable.",
    },
  ];
  return (
    <section
      className="relative isolate text-white"
      style={{
        backgroundImage: `linear-gradient(180deg, rgba(12,6,6,0.65), rgba(12,6,6,0.85)), url(${heroLed})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      <div className="container-editorial py-[120px] lg:py-[180px]">
        <div className="max-w-[720px]">
          <div className="eyebrow !text-[color:var(--taupe)]">{t("The FineLED Standard")}</div>
          <h2 className="display-lg mt-6 text-white">
            {t("A single image, held still.")} <br />
            {t("Three chapters of craft, scrolling by.")}
          </h2>
        </div>

        <div className="mt-24 lg:mt-32 space-y-32 lg:space-y-48">
          {panels.map((p, i) => (
            <div
              key={p.title}
              className={`grid lg:grid-cols-12 gap-10 lg:gap-16 items-center ${
                i % 2 === 1 ? "lg:[&>*:first-child]:order-2" : ""
              }`}
            >
              <div className="lg:col-span-7">
                <div className="group relative overflow-hidden rounded-[24px] border border-white/15 shadow-[0_40px_100px_-30px_rgba(0,0,0,0.7)]">
                  <img
                    src={p.img}
                    alt={p.title}
                    loading="lazy"
                    className="w-full h-[340px] lg:h-[520px] object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-[1.05]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-black/50 via-transparent to-transparent" />
                </div>
              </div>
              <div className="lg:col-span-5">
                <div className="text-[11px] uppercase tracking-[0.24em] text-[color:var(--taupe)]">
                  {t(p.eyebrow)}
                </div>
                <h3 className="mt-6 font-display text-[26px] lg:text-[34px] font-medium tracking-tight leading-[1.2] text-white">
                  {t(p.title)}
                </h3>
                <p className="mt-6 text-[16px] leading-[1.75] text-white/80 max-w-[440px]">
                  {t(p.body)}
                </p>
                <Link
                  to="/products"
                  className="mt-8 inline-flex items-center gap-2 text-[13px] font-medium tracking-wide text-white/90 hover:text-white border-b border-white/40 hover:border-white pb-1"
                >
                  {t("Explore the range")} <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Named exports for other pages ---------------- */

export {
  Hero,
  TrustedBy,
  WhyFineLED,
  About,
  Solutions,
  Industries,
  Projects,
  Process,
  PromiseStats,
  Testimonials,
  Team,
  FAQ,
  Offices,
  FinalCTA,
  ParallaxShowcase,
};

/* ---------------- Page ---------------- */

function Home() {
  return (
    <SiteLayout transparentNav>
      <Hero />
      <Team />
      <TrustedBy />
      <WhyFineLED />
      <ParallaxShowcase />
      <About />
      <Solutions />
      <Industries />
      <Projects />
      <Process />
      <PromiseStats />
      <Testimonials />
      <FAQ />
      <Offices />
      <FinalCTA />
    </SiteLayout>
  );
}


