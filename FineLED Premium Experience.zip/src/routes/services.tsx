import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Building2,
  ClipboardCheck,
  Cpu,
  Globe2,
  Headphones,
  Lightbulb,
  MonitorSpeaker,
  Plane,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Trophy,
  Wrench,
} from "lucide-react";
import projMall from "@/assets/project-mall.jpg";
import solOutdoor from "@/assets/sol-outdoor.jpg";
import solIndoor from "@/assets/sol-indoor.jpg";
import { PageHero, Reveal, SiteLayout } from "@/components/site-chrome";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "LED Services in the GCC — FineLED" },
      {
        name: "description",
        content:
          "End-to-end LED display services across Oman, the UAE and the wider GCC: consultation, engineering, installation, content, control and 24/7 lifecycle support for every industry.",
      },
      { property: "og:title", content: "LED Services across the GCC — FineLED" },
      {
        property: "og:description",
        content:
          "Consultation, engineering, installation, content and 24/7 support for LED displays across the GCC.",
      },
    ],
  }),
  component: ServicesPage,
});

const SERVICES = [
  {
    icon: Lightbulb,
    title: "Consultation & Concept",
    body: "Site surveys, viewing-distance studies and content strategy. We start with the space and the brand, not the panel.",
  },
  {
    icon: ClipboardCheck,
    title: "Engineering & Design",
    body: "Structural drawings, thermal load calcs, power distribution and mock-ups aligned with your architects and MEP consultants.",
  },
  {
    icon: Wrench,
    title: "Supply & Installation",
    body: "Directly sourced fine-pitch and outdoor systems, installed by our own crews with clean cable architecture and factory-grade calibration.",
  },
  {
    icon: MonitorSpeaker,
    title: "Content & Control",
    body: "Processors, scheduling, monitoring dashboards and creative content services so the display keeps earning attention every day.",
  },
  {
    icon: Cpu,
    title: "Audio-Visual Integration",
    body: "LED paired with concert-grade audio, lighting and show control, tuned as one system for venues, studios and stadiums.",
  },
  {
    icon: Headphones,
    title: "24/7 Lifecycle Support",
    body: "Proactive monitoring, regional spares, scheduled calibration and SLA-backed engineering response across the GCC.",
  },
];

const INDUSTRIES = [
  { icon: ShoppingBag, t: "Retail & Shopping Malls", d: "Atrium centrepieces, storefront halos and shop-in-shop screens." },
  { icon: Sparkles, t: "Hospitality & Hotels", d: "Lobby art walls, ballroom rigs and porte-cochère façades." },
  { icon: Building2, t: "Corporate & Command Centres", d: "Reference-grade video walls, boardrooms and NOC displays." },
  { icon: ShieldCheck, t: "Government & Smart Cities", d: "Public information, control rooms and civic media façades." },
  { icon: Plane, t: "Transportation & Airports", d: "FIDS, wayfinding and immersive terminal experiences." },
  { icon: Trophy, t: "Sports & Stadiums", d: "Perimeter boards, scoring, replay and fan-engagement rigs." },
  { icon: Globe2, t: "Events & Exhibitions", d: "Rental-grade touring systems delivered on tight timelines." },
  { icon: Cpu, t: "Broadcast & Media", d: "Studio walls with reference colour and low-latency processing." },
];

const REGIONS = [
  "United Arab Emirates",
  "Sultanate of Oman",
  "Kingdom of Saudi Arabia",
  "Qatar",
  "Bahrain",
  "Kuwait",
];

function ServicesPage() {
  const { t } = useLang();
  return (
    <SiteLayout transparentNav>
      <PageHero
        eyebrow="Services · GCC"
        title={
          <>
            End-to-end LED services, <br /> engineered across the GCC.
          </>
        }
        intro="From first site survey to lifecycle support, FineLED delivers the complete chain of LED and AV services across Oman, the UAE, Saudi Arabia, Qatar, Bahrain and Kuwait — one accountable team, one standard of finish."
        image={projMall}
      />

      {/* Services grid */}
      <section className="bg-background py-[120px] lg:py-[160px]">
        <div className="container-editorial">
          <Reveal>
            <div className="grid lg:grid-cols-12 gap-12">
              <div className="lg:col-span-5">
                <div className="eyebrow">{t("What we do")}</div>
                <h2 className="display-lg mt-6">
                  {t("Six disciplines, delivered under one roof.")}
                </h2>
              </div>
              <div className="lg:col-span-7 lg:pt-4">
                <p className="text-[18px] leading-[1.7] text-[color:var(--text-secondary)] max-w-[620px]">
                  {t("We own every stage of the project so accountability never slips between vendors. The result: displays that look architectural on day one and still calibrate to reference on year ten.")}
                </p>
              </div>
            </div>
          </Reveal>

          <div className="mt-20 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES.map(({ icon: Icon, title, body }, i) => (
              <Reveal key={title} delay={i * 80}>
                <div className="lift-card lift-card-hover bg-card rounded-[18px] border border-border p-10 h-full">
                  <div className="h-12 w-12 rounded-[14px] bg-secondary/10 text-secondary grid place-items-center">
                    <Icon className="h-6 w-6" strokeWidth={1.5} />
                  </div>
                  <h3 className="mt-8 font-display text-[19px] font-medium tracking-tight leading-tight text-primary">
                    {t(title)}
                  </h3>
                  <p className="mt-4 text-[15px] leading-[1.7] text-[color:var(--text-secondary)]">
                    {t(body)}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* GCC coverage band */}
      <section
        className="relative isolate overflow-hidden text-white py-[120px] lg:py-[160px]"
        style={{
          backgroundImage: `linear-gradient(180deg, rgba(12,6,6,0.75), rgba(12,6,6,0.9)), url(${solOutdoor})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundAttachment: "fixed",
        }}
      >
        <div className="container-editorial">
          <Reveal>
            <div className="max-w-[760px]">
              <div className="eyebrow !text-[color:var(--taupe)]">{t("GCC Coverage")}</div>
              <h2 className="display-lg mt-6 text-white">
                {t("One partner. Six markets. Zero hand-offs.")}
              </h2>
              <p className="mt-8 text-[18px] leading-[1.7] text-white/80 max-w-[560px]">
                {t("From flagship malls in Dubai and airports in Muscat to civic installations in Riyadh, our engineers, spares and support run on the same clock across the region.")}
              </p>
            </div>
          </Reveal>

          <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {REGIONS.map((r, i) => (
              <Reveal key={r} delay={i * 60}>
                <div className="rounded-[16px] border border-white/20 bg-white/[0.06] backdrop-blur-xl px-6 py-5 flex items-center gap-4 hover:bg-white/[0.10] hover:border-white/40 transition-colors">
                  <span className="h-2 w-2 rounded-full bg-[color:var(--taupe)]" />
                  <span className="font-display text-[16px] font-medium text-white">{t(r)}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Industries served (merged) */}
      <section className="bg-[oklch(0.93_0.014_75)] py-[120px] lg:py-[160px]">
        <div className="container-editorial">
          <Reveal>
            <div className="grid lg:grid-cols-12 gap-12">
              <div className="lg:col-span-5">
                <div className="eyebrow">{t("Industries served")}</div>
                <h2 className="display-lg mt-6 text-primary">
                  {t("Sectors that don't allow for compromise.")}
                </h2>
              </div>
              <div className="lg:col-span-7 lg:pt-4">
                <p className="text-[18px] leading-[1.7] text-[color:var(--text-secondary)] max-w-[620px]">
                  {t("Our services flex to the sectors where downtime and drift are not options — from five-star hospitality to government command centres.")}
                </p>
              </div>
            </div>
          </Reveal>

          <div className="mt-20 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {INDUSTRIES.map(({ icon: Icon, t: label, d }, i) => (
              <Reveal key={label} delay={i * 60}>
                <div className="lift-card lift-card-hover bg-card rounded-[18px] border border-border p-8 h-full">
                  <Icon className="h-6 w-6 text-secondary" strokeWidth={1.5} />
                  <div className="mt-6 font-display text-[17px] font-medium tracking-tight text-primary">
                    {t(label)}
                  </div>
                  <p className="mt-3 text-[14px] leading-[1.65] text-[color:var(--text-secondary)]">
                    {t(d)}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-background py-[100px] lg:py-[140px]">
        <div className="container-editorial">
          <Reveal>
            <div className="rounded-[24px] bg-primary text-white p-12 lg:p-20 grid lg:grid-cols-12 gap-10 items-end">
              <div className="lg:col-span-8">
                <div className="eyebrow !text-[color:var(--taupe)]">{t("Start a project")}</div>
                <h2 className="display-lg mt-6 text-white max-w-[720px]">
                  {t("Bring us the site. We'll bring the standard.")}
                </h2>
              </div>
              <div className="lg:col-span-4 lg:text-right rtl:lg:text-left">
                <Link
                  to="/quote"
                  className="inline-flex items-center gap-2 h-14 px-9 rounded-[14px] bg-white text-primary text-[15px] font-medium hover:bg-[color:var(--taupe)] transition-colors"
                >
                  {t("Request a proposal")} <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </SiteLayout>
  );
}
