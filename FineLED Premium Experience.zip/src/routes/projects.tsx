import { createFileRoute } from "@tanstack/react-router";
import projBillboard from "@/assets/project-billboard.jpg";
import { PageHero, SiteLayout } from "@/components/site-chrome";
import { Projects, ParallaxShowcase, Process, Testimonials } from "./index";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — FineLED" },
      {
        name: "description",
        content:
          "Featured LED display installations across Dubai, Abu Dhabi, Muscat and the wider GCC — architecture, retail, transport and hospitality.",
      },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  return (
    <SiteLayout transparentNav>
      <PageHero
        eyebrow="Featured Projects"
        title={
          <>
            Selected work, <br /> across the region.
          </>
        }
        intro="A curated look at recent FineLED installations, from building-integrated façades to fine-pitch interiors and mission-critical information displays."
        image={projBillboard}
      />
      <Projects />
      <ParallaxShowcase />
      <Process />
      <Testimonials />
    </SiteLayout>
  );
}
