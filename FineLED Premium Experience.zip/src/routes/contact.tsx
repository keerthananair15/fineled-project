import { createFileRoute } from "@tanstack/react-router";
import projHotel from "@/assets/project-hotel.jpg";
import { PageHero, SiteLayout } from "@/components/site-chrome";
import { Offices, FAQ, FinalCTA } from "./index";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact FineLED — Dubai & Muscat" },
      {
        name: "description",
        content:
          "Talk to FineLED. Two regional hubs in Dubai and Muscat, 24/7 engineering support, one accountable team.",
      },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <SiteLayout transparentNav>
      <PageHero
        eyebrow="Contact"
        title={
          <>
            Two hubs. <br /> One accountable team.
          </>
        }
        intro="Reach us in Dubai or Muscat. Our engineering, project and support teams respond within one business day, twenty-four hours a day."
        image={projHotel}
      />
      <Offices />
      <FAQ />
      <FinalCTA />
    </SiteLayout>
  );
}
