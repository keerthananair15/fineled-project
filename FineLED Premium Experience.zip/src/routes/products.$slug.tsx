import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, ArrowLeft } from "lucide-react";
import { getProduct, products } from "@/lib/products";
import { SiteLayout } from "@/components/site-chrome";


export const Route = createFileRoute("/products/$slug")({
  loader: ({ params }) => {
    const product = getProduct(params.slug);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => {
    const p = loaderData?.product;
    const title = p ? `${p.name} — FineLED` : "Product — FineLED";
    const desc = p?.tagline ?? "Premium LED display solutions by FineLED.";
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        ...(p?.hero ? [{ property: "og:image", content: p.hero }] : []),
        ...(p?.hero ? [{ name: "twitter:image", content: p.hero }] : []),
      ],
    };
  },
  notFoundComponent: () => (
    <main className="min-h-screen grid place-items-center bg-background px-6">
      <div className="text-center max-w-md">
        <h1 className="display-lg text-primary">Product not found</h1>
        <p className="mt-4 text-[color:var(--text-secondary)]">
          The product you're looking for doesn't exist or has been moved.
        </p>
        <Link to="/products" className="inline-flex items-center gap-2 mt-8 text-secondary hover:text-primary font-medium">
          <ArrowLeft className="h-4 w-4" /> View all products
        </Link>
      </div>
    </main>
  ),
  errorComponent: ({ error, reset }) => (
    <main className="min-h-screen grid place-items-center bg-background px-6">
      <div className="text-center max-w-md">
        <h1 className="display-lg text-primary">Something went wrong</h1>
        <p className="mt-4 text-[color:var(--text-secondary)]">{error.message}</p>
        <button onClick={reset} className="mt-8 inline-flex items-center gap-2 text-secondary hover:text-primary font-medium">
          Try again
        </button>
      </div>
    </main>
  ),
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const product = getProduct(slug)!;
  const related = products.filter((p) => p.slug !== product.slug).slice(0, 3);

  return (
    <SiteLayout>
      {/* Hero */}
      <section className="relative isolate overflow-hidden bg-[#0c0606] pt-[140px] pb-24 lg:pt-[180px] lg:pb-32">
        <img
          src={product.hero}
          alt=""
          aria-hidden
          className="absolute inset-0 h-full w-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/60 to-black/80" />
        <div className="relative container-editorial">
          <Link
            to="/products"
            className="inline-flex items-center gap-2 text-white/70 hover:text-white text-[13px] tracking-wide uppercase font-medium"
          >
            <ArrowLeft className="h-4 w-4" /> All Products
          </Link>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <span className="font-display text-[12px] tracking-[0.22em] uppercase text-white/90 backdrop-blur-md bg-white/10 border border-white/20 rounded-full px-3 py-1">
              {product.category}
            </span>
          </div>
          <h1 className="display-xl mt-6 text-white max-w-[900px]">{product.name}</h1>
          <p className="mt-6 text-[19px] lg:text-[21px] leading-[1.55] text-white/85 max-w-[720px]">
            {product.tagline}
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <a
              href="/quote"
              className="inline-flex items-center justify-center gap-2 h-14 px-9 rounded-[14px] text-[15px] font-medium tracking-tight bg-secondary text-white hover:bg-primary transition-all"
            >
              Get a Quotation <ArrowRight className="h-4 w-4" />
            </a>
            <Link
              to="/products"
              className="inline-flex items-center justify-center gap-2 h-14 px-9 rounded-[14px] text-[15px] font-medium tracking-tight bg-transparent text-white border border-white/40 hover:bg-white hover:text-primary transition-all"
            >
              Browse Range
            </Link>
          </div>
        </div>
      </section>

      {/* Overview + Highlights */}
      <section className="py-[100px] lg:py-[140px] bg-card">
        <div className="container-editorial grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-7">
            <div className="eyebrow">Overview</div>
            <h2 className="display-lg mt-6 text-primary">Built to a single standard of finish.</h2>
            <p className="mt-8 text-[17px] leading-[1.75] text-[color:var(--text-secondary)]">
              {product.description}
            </p>
          </div>
          <div className="lg:col-span-5">
            <div className="eyebrow">Highlights</div>
            <ul className="mt-6 space-y-4">
              {product.highlights.map((h) => (
                <li key={h} className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-secondary shrink-0 mt-0.5" strokeWidth={1.75} />
                  <span className="text-[15px] leading-[1.65] text-primary">{h}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Specs */}
      <section className="py-[100px] lg:py-[140px] bg-[oklch(0.93_0.014_75)]">
        <div className="container-editorial">
          <div className="eyebrow">Specifications</div>
          <h2 className="display-lg mt-6 text-primary max-w-[720px]">Technical specifications</h2>
          <div className="mt-14 overflow-hidden rounded-[20px] border border-border bg-card">
            <dl className="divide-y divide-border">
              {product.specs.map((s) => (
                <div
                  key={s.label}
                  className="grid grid-cols-1 md:grid-cols-3 gap-2 px-8 py-6"
                >
                  <dt className="font-display text-[14px] tracking-[0.16em] uppercase text-[color:var(--text-secondary)]">
                    {s.label}
                  </dt>
                  <dd className="md:col-span-2 text-[16px] text-primary">{s.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      {/* Applications */}
      <section className="py-[100px] lg:py-[140px] bg-card">
        <div className="container-editorial">
          <div className="grid lg:grid-cols-12 gap-12">
            <div className="lg:col-span-5">
              <div className="eyebrow">Applications</div>
              <h2 className="display-lg mt-6 text-primary">Where it performs best.</h2>
            </div>
            <div className="lg:col-span-7 flex flex-wrap gap-3">
              {product.applications.map((a) => (
                <span
                  key={a}
                  className="inline-flex items-center h-11 px-5 rounded-full bg-background border border-border text-[14px] font-medium text-primary hover:border-secondary transition-colors"
                >
                  {a}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Gallery */}
      {product.gallery.length > 0 && (
        <section className="py-[100px] lg:py-[140px] bg-background">
          <div className="container-editorial">
            <div className="eyebrow">Gallery</div>
            <h2 className="display-lg mt-6 text-primary max-w-[720px]">Real installations & references</h2>
            <div className="mt-14 grid md:grid-cols-2 gap-6">
              {product.gallery.map((src, i) => (
                <div key={i} className="relative overflow-hidden rounded-[20px] aspect-[4/3] bg-accent">
                  <img src={src} alt={`${product.name} reference ${i + 1}`} loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="py-[100px] lg:py-[140px] bg-[color:var(--wine,#561c24)] text-white">
        <div className="container-editorial text-center">
          <h2 className="display-lg text-white max-w-[820px] mx-auto">
            Ready to specify your {product.name.toLowerCase()}?
          </h2>
          <p className="mt-6 text-[17px] leading-[1.7] text-white/80 max-w-[620px] mx-auto">
            Our engineers will size, spec and quote your installation — usually within 24 hours.
          </p>
          <div className="mt-10">
            <a
              href="/quote"
              className="inline-flex items-center justify-center gap-2 h-14 px-9 rounded-[14px] text-[15px] font-medium tracking-tight bg-white text-primary hover:bg-white/90 transition-all"
            >
              Request a Quotation <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </section>

      {/* Related */}
      <section className="py-[100px] lg:py-[140px] bg-background">
        <div className="container-editorial">
          <div className="eyebrow">Related products</div>
          <h2 className="display-lg mt-6 text-primary">Explore the rest of the range.</h2>
          <div className="mt-14 grid md:grid-cols-3 gap-7">
            {related.map((p) => (
              <Link
                key={p.slug}
                to="/products/$slug"
                params={{ slug: p.slug }}
                className="group relative overflow-hidden rounded-[20px] border border-border bg-card transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_30px_60px_-20px_rgba(86,28,36,0.28)]"
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-accent">
                  <img src={p.hero} alt={p.name} loading="lazy" className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1200ms] group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                  <h3 className="absolute left-5 right-5 bottom-5 font-display text-[20px] font-medium text-white">{p.name}</h3>
                </div>
                <div className="p-6">
                  <p className="text-[14px] leading-[1.6] text-[color:var(--text-secondary)]">{p.tagline}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>

  );
}
