import { createFileRoute } from "@tanstack/react-router";
import projMall from "@/assets/project-mall.jpg";
import { PageHero, SiteLayout } from "@/components/site-chrome";
import { Industries, Projects, TrustedBy } from "./index";

export const Route = createFileRoute("/industries")({
  head: () => ({
    meta: [
      { title: "Industries — FineLED" },
      {
        name: "description",
        content:
          "LED display solutions for retail, hospitality, corporate, government, transportation, sports, events and broadcast across the GCC.",
      },
    ],
  }),
  component: IndustriesPage,
});

function IndustriesPage() {
  return (
    <SiteLayout transparentNav>
      <PageHero
        eyebrow="Industries"
        title={
          <>
            Sectors that don't <br /> allow for compromise.
          </>
        }
        intro="From flagship malls and five-star hotels to airports, stadiums and government command centres, FineLED partners with the sectors where downtime and drift are not options."
        image={projMall}
      />
      <Industries />
      <Projects />
      <TrustedBy />
    </SiteLayout>
  );
}
