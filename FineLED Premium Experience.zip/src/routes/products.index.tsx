import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { products } from "@/lib/products";
import { PageHero, SiteLayout } from "@/components/site-chrome";
import { useLang } from "@/lib/i18n";
import solIndoor from "@/assets/sol-indoor.jpg";

export const Route = createFileRoute("/products/")({
  head: () => ({
    meta: [
      { title: "LED Display Products — FineLED" },
      {
        name: "description",
        content:
          "Explore the full FineLED product range: indoor & outdoor LED displays, transparent, hologram fan, portable, floor, flexible, scrolling, stadium, rental, food delivery boxes and interactive kiosks.",
      },
      { property: "og:title", content: "LED Display Products — FineLED" },
      {
        property: "og:description",
        content:
          "The complete FineLED catalogue of LED display solutions for indoor, outdoor, creative, rental and interactive environments.",
      },
    ],
  }),
  component: ProductsIndex,
});

function ProductsIndex() {
  const { t } = useLang();
  return (
    <SiteLayout transparentNav>
      <PageHero
        eyebrow={t("Solutions")}
        title={
          <>
            {t("The complete FineLED")} <br /> {t("product catalogue.")}
          </>
        }
        intro={t(
          "Twelve engineered product families. One standard of finish. Explore the range and open any product for full specifications, applications and imagery.",
        )}
        image={solIndoor}
      />

      <section className="py-[100px] lg:py-[140px]">
        <div className="container-editorial">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-7">
            {products.map((p, i) => (
              <Link
                key={p.slug}
                to="/products/$slug"
                params={{ slug: p.slug }}
                className="group relative overflow-hidden rounded-[20px] border border-border bg-card transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_30px_60px_-20px_rgba(86,28,36,0.28)]"
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-accent">
                  <img
                    src={p.hero}
                    alt={t(p.name)}
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                  <div className="absolute inset-x-0 top-0 flex items-start justify-between p-5">
                    <span className="font-display text-[12px] tracking-[0.22em] uppercase text-white/90 backdrop-blur-md bg-black/25 border border-white/20 rounded-full px-3 py-1">
                      {String(i + 1).padStart(2, "0")} · {t(p.category)}
                    </span>
                    <span className="h-9 w-9 grid place-items-center rounded-full backdrop-blur-md bg-white/15 border border-white/30 text-white transition-transform duration-500 group-hover:rotate-45">
                      <ArrowUpRight className="h-4 w-4" />
                    </span>
                  </div>
                  <h2 className="absolute left-5 right-5 bottom-5 font-display text-[20px] lg:text-[22px] font-medium tracking-tight leading-tight text-white">
                    {t(p.name)}
                  </h2>
                </div>
                <div className="p-7 lg:p-8">
                  <p className="text-[15px] leading-[1.7] text-[color:var(--text-secondary)]">
                    {t(p.tagline)}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
