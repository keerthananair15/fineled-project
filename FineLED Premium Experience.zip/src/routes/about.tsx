import { createFileRoute } from "@tanstack/react-router";
import aboutLed from "@/assets/about-led.jpg";
import { PageHero, SiteLayout } from "@/components/site-chrome";
import { About, WhyFineLED, PromiseStats, TrustedBy } from "./index";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About FineLED — Engineering brightness for the GCC" },
      {
        name: "description",
        content:
          "Twenty-five years of LED, AV and signage craftsmanship, headquartered in Dubai with regional operations in Muscat. Meet the team behind FineLED.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <SiteLayout transparentNav>
      <PageHero
        eyebrow="About FineLED"
        title={
          <>
            Twenty-five years <br /> of light, engineered.
          </>
        }
        intro="Headquartered in the UAE with regional operations in the Sultanate of Oman, FineLED designs, engineers and installs landmark LED displays for the region's most demanding spaces."
        image={aboutLed}
      />
      <About variant="detail" />
      <WhyFineLED />
      <PromiseStats />
      <TrustedBy />

    </SiteLayout>
  );
}
