import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  Clock,
  Mail,
  MapPin,
  Phone,
  Quote as QuoteIcon,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import heroLed from "@/assets/hero-led.jpg";
import { Reveal, SiteLayout } from "@/components/site-chrome";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/quote")({
  head: () => ({
    meta: [
      { title: "Get a Quote — FineLED" },
      {
        name: "description",
        content:
          "Request a proposal from FineLED. Share your project brief and our engineers will size, spec and quote your LED installation, usually within 24 hours.",
      },
    ],
  }),
  component: QuotePage,
});

const PRODUCTS = [
  "Indoor LED",
  "Outdoor LED",
  "Transparent LED",
  "Curved / Creative LED",
  "Rental LED",
  "Stadium LED",
  "Interactive Kiosk",
  "Not sure yet",
];

const BUDGETS = ["< $10k", "$10k – $50k", "$50k – $200k", "$200k – $1M", "$1M+"];

function QuotePage() {
  const { t } = useLang();
  const [submitted, setSubmitted] = useState(false);

  return (
    <SiteLayout transparentNav>
      {/* Hero with sticky parallax background */}
      <section
        className="relative isolate overflow-hidden text-white pt-[180px] pb-24 lg:pt-[220px] lg:pb-32"
        style={{
          backgroundImage: `linear-gradient(180deg, rgba(12,6,6,0.72), rgba(12,6,6,0.88)), url(${heroLed})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundAttachment: "fixed",
        }}
      >
        <div className="container-editorial relative">
          <div className="max-w-[760px]">
            <div className="eyebrow !text-[color:var(--taupe)]">{t("Get a Quote")}</div>
            <h1 className="display-xl mt-6 text-white">
              {t("Tell us about the space.")} <br />
              {t("We'll tell you what's possible.")}
            </h1>
            <p className="mt-8 max-w-[560px] text-[18px] leading-[1.7] text-white/85">
              {t("Share your brief and our engineers will size, spec and quote your LED installation, usually within 24 hours.")}
            </p>
          </div>
        </div>
      </section>

      {/* Form + Side card */}
      <section className="bg-background py-[100px] lg:py-[140px]">
        <div className="container-editorial grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-7">
            {submitted ? (
              <div className="rounded-[24px] border border-border bg-card p-12 lg:p-16 text-center">
                <div className="mx-auto h-14 w-14 rounded-full bg-primary/10 text-primary grid place-items-center">
                  <CheckCircle2 className="h-7 w-7" strokeWidth={1.5} />
                </div>
                <h2 className="mt-8 font-display text-[28px] lg:text-[36px] font-medium tracking-tight text-primary">
                  {t("Thank you.")}
                </h2>
                <p className="mt-4 text-[16px] leading-[1.7] text-[color:var(--text-secondary)] max-w-[440px] mx-auto">
                  {t("Your brief has been received. A member of our team will reply within one business day.")}
                </p>
                <Link
                  to="/"
                  className="mt-10 inline-flex items-center gap-2 text-secondary hover:text-primary font-medium"
                >
                  {t("Back to home")} <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                </Link>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setSubmitted(true);
                }}
                className="rounded-[24px] border border-border bg-card p-8 lg:p-12 space-y-8"
              >
                <div className="grid sm:grid-cols-2 gap-6">
                  <Field label={t("Full name")} required>
                    <input required type="text" className={inputCls} placeholder="Jane Doe" />
                  </Field>
                  <Field label={t("Company")}>
                    <input type="text" className={inputCls} placeholder={t("Company name")} />
                  </Field>
                  <Field label={t("Work email")} required>
                    <input required type="email" className={inputCls} placeholder="you@company.com" />
                  </Field>
                  <Field label={t("Phone")}>
                    <input type="tel" className={inputCls} placeholder="+971 ..." />
                  </Field>
                </div>

                <Field label={t("Project location")}>
                  <input type="text" className={inputCls} placeholder={t("City, country")} />
                </Field>

                <Field label={t("Product interest")}>
                  <select className={inputCls}>
                    {PRODUCTS.map((p) => (
                      <option key={p}>{t(p)}</option>
                    ))}
                  </select>
                </Field>

                <Field label={t("Indicative budget")}>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {BUDGETS.map((b) => (
                      <label
                        key={b}
                        className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-4 py-2 text-[13px] text-primary cursor-pointer has-[:checked]:border-secondary has-[:checked]:bg-secondary/10 transition-colors"
                      >
                        <input type="radio" name="budget" className="sr-only" />
                        {b}
                      </label>
                    ))}
                  </div>
                </Field>

                <Field label={t("Tell us about the project")} required>
                  <textarea
                    required
                    rows={5}
                    className={`${inputCls} resize-y`}
                    placeholder={t("Space, timeline, references, any constraints...")}
                  />
                </Field>

                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-2 h-14 px-9 rounded-[14px] text-[15px] font-medium tracking-tight bg-secondary text-white hover:bg-primary shadow-[0_1px_2px_rgba(86,28,36,0.06)] hover:shadow-[0_18px_40px_rgba(86,28,36,0.18)] transition-all"
                >
                  {t("Send Request")} <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                </button>
              </form>
            )}
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-5 space-y-6 lg:sticky lg:top-28 lg:self-start">
            {/* Premium promise card — dark burgundy glass */}
            <Reveal>
              <div className="relative isolate overflow-hidden rounded-[20px] border border-[color:var(--wine)]/30 bg-gradient-to-br from-[color:var(--wine)] via-[oklch(0.22_0.04_25)] to-[oklch(0.18_0.02_30)] p-6 lg:p-7 text-white shadow-[0_20px_60px_-30px_rgba(86,28,36,0.6)]">
                <div
                  className="absolute inset-0 -z-10 opacity-80 pointer-events-none"
                  style={{
                    background:
                      "radial-gradient(60% 55% at 80% 20%, rgba(214,170,140,0.22), transparent 70%), radial-gradient(50% 50% at 10% 90%, rgba(109,41,50,0.5), transparent 70%)",
                  }}
                />
                <div className="eyebrow !text-[color:var(--taupe)]">{t("The FineLED Promise")}</div>
                <p className="mt-4 font-display text-[15px] lg:text-[16px] font-medium leading-[1.5] tracking-tight text-white/95">
                  {t("Every brief is priced by the engineer who will deliver it, not by a call centre.")}
                </p>
                <div className="mt-5 pt-5 border-t border-white/15 grid grid-cols-3 gap-3 text-center">
                  {[
                    ["25+", t("Years")],
                    ["3000+", t("Projects")],
                    ["24/7", t("Support")],
                  ].map(([k, v]) => (
                    <div key={String(v)}>
                      <div className="font-display text-[18px] font-medium text-white leading-none">{k}</div>
                      <div className="mt-1.5 text-[9px] uppercase tracking-[0.2em] text-white/60">{v}</div>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>

            {/* What happens next */}
            <Reveal delay={100}>
              <div className="rounded-[20px] border border-border bg-card p-6 lg:p-7">
                <div className="flex items-center gap-3">
                  <div className="h-9 w-9 rounded-full bg-primary/10 text-primary grid place-items-center">
                    <Sparkles className="h-4 w-4" strokeWidth={1.75} />
                  </div>
                  <div className="font-display text-[15px] font-medium text-primary">
                    {t("What happens next")}
                  </div>
                </div>
                <ol className="mt-4 space-y-3 text-[13px] leading-[1.55] text-[color:var(--text-secondary)]">
                  {[
                    "We review your brief within a business day.",
                    "A short discovery call to align on scope and timeline.",
                    "You receive a detailed proposal with budget and delivery plan.",
                  ].map((s, i) => (
                    <li key={s} className="flex gap-3">
                      <span className="shrink-0 h-5 w-5 rounded-full bg-secondary/15 text-secondary grid place-items-center text-[11px] font-semibold">
                        {i + 1}
                      </span>
                      <span>{t(s)}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </Reveal>

            {/* Trust badges */}
            <Reveal delay={180}>
              <div className="grid grid-cols-2 gap-2.5">
                {[
                  { icon: Zap, label: "24-hour response" },
                  { icon: ShieldCheck, label: "ISO 9001 Certified" },
                  { icon: Clock, label: "Fixed timelines" },
                  { icon: CheckCircle2, label: "No obligation" },
                ].map(({ icon: Icon, label }) => (
                  <div
                    key={label}
                    className="rounded-[12px] border border-border bg-card px-3 py-3 flex items-center gap-2.5"
                  >
                    <Icon className="h-4 w-4 text-secondary shrink-0" strokeWidth={1.75} />
                    <span className="text-[11.5px] font-medium tracking-tight text-primary leading-tight">
                      {t(label)}
                    </span>
                  </div>
                ))}
              </div>
            </Reveal>

            {/* Reach us */}
            <Reveal delay={240}>
              <div className="rounded-[20px] border border-border bg-[oklch(0.93_0.014_75)] p-6 lg:p-7">
                <div className="eyebrow">{t("Reach us directly")}</div>
                <ul className="mt-4 space-y-3 text-[13px] text-primary">
                  <li className="flex items-center gap-3">
                    <MapPin className="h-4 w-4 text-secondary" /> {t("Dubai · Muscat")}
                  </li>
                  <li>
                    <a href="tel:+971504235194" className="flex items-center gap-3 hover:text-secondary">
                      <Phone className="h-4 w-4 text-secondary" /> +971 50 4235 194
                    </a>
                  </li>
                  <li>
                    <a
                      href="mailto:contact@fineledscreen.com"
                      className="flex items-center gap-3 hover:text-secondary"
                    >
                      <Mail className="h-4 w-4 text-secondary" /> contact@fineledscreen.com
                    </a>
                  </li>
                  <li className="flex items-center gap-3">
                    <Clock className="h-4 w-4 text-secondary" /> {t("24/7 Engineering Support")}
                  </li>
                </ul>
              </div>
            </Reveal>
          </aside>
        </div>
      </section>
    </SiteLayout>
  );
}

const inputCls =
  "block w-full rounded-[12px] border border-border bg-background px-4 py-3 text-[15px] text-primary placeholder:text-[color:var(--text-secondary)]/60 focus:outline-none focus:border-secondary focus:ring-2 focus:ring-secondary/20 transition-colors";

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-[12px] uppercase tracking-[0.18em] text-[color:var(--text-secondary)]">
        {label} {required && <span className="text-secondary">*</span>}
      </span>
      <div className="mt-2">{children}</div>
    </label>
  );
}
